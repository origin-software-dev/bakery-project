<?php
// Heading
$_['heading_title']    = 'Themability Search';

$_['text_extensions']   = 'Extensions';
$_['text_success']     = 'Success: You have modified themability module!';
$_['text_edit']        = 'Edit themability search Module';

// Entry
$_['entry_status']     = 'Status';
$_['entry_autocomplete'] = 'Autocomplete';
$_['entry_category']   = 'Categoty';
$_['text_general']   = 'General';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify themability search module!';
