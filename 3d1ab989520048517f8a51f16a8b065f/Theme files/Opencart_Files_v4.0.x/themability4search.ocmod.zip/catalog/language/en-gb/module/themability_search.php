<?php
// Text
$_['text_search']       = 'Search...';

$_['text_category']     = 'All Categories';
$_['text_sub_category'] = 'Search in subcategories';
// Text

// Entry
$_['entry_search']      = 'Search Criteria';
$_['entry_description'] = 'Search in product descriptions';
