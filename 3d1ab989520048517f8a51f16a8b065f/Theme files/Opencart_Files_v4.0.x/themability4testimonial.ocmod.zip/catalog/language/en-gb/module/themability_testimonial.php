<?php
// Heading Themability Testimonials
$_['heading_title']  = 'Testimonials';
$_['text_readmore']  = 'Read more';
$_['text_empty']  	 = 'There is no testimonial';
$_['text_customer']  = 'Customer';
?>