<?php
$_['text_footer_left'] 	  = 'Themability Footer Left';
$_['text_footer_right']   = 'Themability Footer Right';