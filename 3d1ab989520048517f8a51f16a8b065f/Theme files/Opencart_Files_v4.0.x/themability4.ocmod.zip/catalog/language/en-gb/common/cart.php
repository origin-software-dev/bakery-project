<?php
// Text
// $_['text_items_header_cart']  = '%s <span>items %s</span>';
$_['text_items_header_cart']  = '%s';
$_['my_cart']                 = 'My Cart';